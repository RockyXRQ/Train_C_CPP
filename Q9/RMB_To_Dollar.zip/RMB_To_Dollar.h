#ifndef _RMB_TO_DOLLAR_H
#define _RMB_TO_DOLLAR_H

#pragma once

#include "Include_List.h"

float RMB_To_Dollar();

#endif