#include "Include_List.h"
#include "RMB_To_Dollar.h"

int main(){

RMB_To_Dollar();
system("pause");

return 0;

}